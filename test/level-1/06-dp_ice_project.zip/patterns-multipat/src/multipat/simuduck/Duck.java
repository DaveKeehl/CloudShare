package multipat.simuduck;

public interface Duck {

    void swim ();

    void quack ();

    void fly ();

    void display ();

}
