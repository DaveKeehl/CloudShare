package multipat.simuduck.v0.initial;

class RedheadDuck extends AbstractDuck {

    @Override
    public void display () {
        System.out.println ("I am a real Red Headed duck!");
    }

}
