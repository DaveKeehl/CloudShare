package multipat.simuduck.v0.initial;

class RubberDuck extends AbstractDuck {

    @Override
    public void display () {
        System.out.println ("I'm a Rubber duckie!");
    }


    @Override
    public void quack () {
        System.out.println ("Squeak!");
    }


    @Override
    public void fly () {
        // Rubber ducks don't fly.
    }

}
