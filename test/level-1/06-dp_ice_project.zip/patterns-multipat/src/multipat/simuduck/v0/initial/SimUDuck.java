package multipat.simuduck.v0.initial;

import multipat.simuduck.Duck;

class SimUDuck {

    private static void __exerciseDuck (final Duck duck) {
        duck.display ();
        duck.quack ();
        duck.swim ();
        duck.fly ();
    }

    private static void __exerciseDucks (
        final int round, final Duck ... ducks
    ) {
        System.out.println ("=======");
        System.out.printf ("Round %d\n", round);
        System.out.println ("=======");

        String delimiter = "";
        for (final Duck duck : ducks) {
            System.out.print (delimiter);
            __exerciseDuck (duck);
            delimiter = "---\n";
        }
    }

    //

    public static void main (final String ... args) {
        final Duck redHeadDuck = new RedheadDuck ();
        final Duck mallardDuck = new MallardDuck ();
        final Duck rubberDuck = new RubberDuck ();
        final Duck decoyDuck = new DecoyDuck ();

        __exerciseDucks (0, redHeadDuck, mallardDuck, rubberDuck, decoyDuck);
        __exerciseDucks (1, redHeadDuck, mallardDuck, rubberDuck, decoyDuck);
    }

}
