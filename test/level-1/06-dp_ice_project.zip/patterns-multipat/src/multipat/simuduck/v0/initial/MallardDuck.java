package multipat.simuduck.v0.initial;

class MallardDuck extends AbstractDuck {

    @Override
    public void display () {
        System.out.println ("I am a real Mallard duck!");
    }

}
