package multipat.simuduck.v0.initial;

class DecoyDuck extends AbstractDuck {

    @Override
    public void display () {
        System.out.println ("I'm a duck Decoy!");
    }


    @Override
    public void quack () {
        // Decoys are mute.
    }


    @Override
    public void fly () {
        // Decoys don't fly.
    }

}
