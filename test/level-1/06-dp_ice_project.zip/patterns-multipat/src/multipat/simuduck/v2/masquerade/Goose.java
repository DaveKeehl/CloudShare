package multipat.simuduck.v2.masquerade;

public class Goose {

        public void display () {
            System.out.println ("I'm a Goose!");
        }


        public void fly () {
            System.out.println ("Geese can fly just fine!");
        }


        public void honk () {
            System.out.println ("Honk!");
        }

}
